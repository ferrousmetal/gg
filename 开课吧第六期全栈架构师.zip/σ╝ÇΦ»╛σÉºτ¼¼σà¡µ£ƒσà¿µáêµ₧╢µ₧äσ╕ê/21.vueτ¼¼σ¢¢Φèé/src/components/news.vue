<template lang="html">
  <div class="">
    新闻
  </div>
</template>

<script>
export default {
  name: 'news',
  data(){
    return {}
  }
}
</script>

<style lang="css" scoped>
</style>
