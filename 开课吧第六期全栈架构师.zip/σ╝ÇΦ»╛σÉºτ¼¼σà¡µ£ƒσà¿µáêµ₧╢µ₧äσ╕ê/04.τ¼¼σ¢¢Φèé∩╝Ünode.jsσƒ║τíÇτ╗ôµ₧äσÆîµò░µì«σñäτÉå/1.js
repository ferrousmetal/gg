/*const mod1=require('mod1');

console.log(mod1.a);
console.log(mod1.b);
console.log(mod1.c);*/

const mod1=require('mod1');

//mod1();

let p=new mod1(99);

p.show();
