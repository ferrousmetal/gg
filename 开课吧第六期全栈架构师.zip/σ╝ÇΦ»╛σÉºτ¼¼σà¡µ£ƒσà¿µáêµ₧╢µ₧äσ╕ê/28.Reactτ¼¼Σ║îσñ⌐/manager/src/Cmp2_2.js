import React, {Component} from 'react';

class Cmp22 extends Component{
  constructor(...args){
    super(...args);
  }

  render(){
    return (
      <div>
        社会新闻
      </div>
    );
  }
}

export default Cmp22;
