import React, { Component } from 'react';
import './App.css';

import Cmp1 from './Cmp1';

class App extends Component {
  render() {
    return (
      <div>
        aaaa
        <Cmp1/>
      </div>
    );
  }
}

export default App;
