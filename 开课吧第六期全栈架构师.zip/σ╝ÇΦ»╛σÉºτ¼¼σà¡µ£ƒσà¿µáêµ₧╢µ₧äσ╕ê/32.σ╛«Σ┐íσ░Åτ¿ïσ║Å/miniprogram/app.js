App({
  //生命周期
  onLaunch(){

  },
  onShow(){

  },
  onHide(){

  },
  //报错
  onError(){

  },
  onPageNotFound(){

  },

  //整个程序之内共享的
  a: 12,
  user: {
    name: 'blue'
  }
})