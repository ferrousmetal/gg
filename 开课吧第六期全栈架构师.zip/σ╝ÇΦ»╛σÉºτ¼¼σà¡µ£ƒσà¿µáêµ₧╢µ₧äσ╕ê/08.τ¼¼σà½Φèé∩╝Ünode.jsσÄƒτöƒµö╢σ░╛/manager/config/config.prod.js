module.exports={
  //database
  DB_HOST: '21.34.98.75',
  DB_PORT: 3309,
  DB_USER: 'root',
  DB_PASS: '123456',
  DB_NAME: 'comp'
};
