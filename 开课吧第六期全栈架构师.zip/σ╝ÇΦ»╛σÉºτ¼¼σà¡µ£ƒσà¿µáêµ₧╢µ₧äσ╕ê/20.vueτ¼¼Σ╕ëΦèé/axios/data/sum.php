<?PHP
echo $_POST['a']+$_POST['b'];
?>
