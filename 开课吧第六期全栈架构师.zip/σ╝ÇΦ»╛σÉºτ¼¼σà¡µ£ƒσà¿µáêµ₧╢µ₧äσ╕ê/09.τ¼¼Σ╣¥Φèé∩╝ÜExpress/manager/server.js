const db=require('./libs/database');
const http=require('./libs/http');
const routers=require('./routers');

const process=require('process');

console.log(process.argv);
