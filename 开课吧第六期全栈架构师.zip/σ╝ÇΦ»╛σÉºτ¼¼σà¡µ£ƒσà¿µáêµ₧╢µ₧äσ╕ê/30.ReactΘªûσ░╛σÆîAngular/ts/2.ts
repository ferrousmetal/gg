function sum(a:number, b:number):number{
  return a+b;
}

console.log(sum(12, 5));
