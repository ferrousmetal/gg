let a:number=12;

a='abc';

console.log(a);
