let str='sdfw4 e34 w345w rtw435t4w55';
console.log(str.match(/\d+/g));
