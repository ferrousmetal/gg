let a=12;
let b=5;

console.log(a+b);
