//import $ from 'jquery';
//import "../css/main.css";
//import "../less/1.less";

let a=12;
let b=35;
let name="blue";
let n2="blue";

const sum=(n1,n2)=>(n1+n2);

//alert(sum(a,b));
