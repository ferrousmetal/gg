let a=12;

alert(a);
