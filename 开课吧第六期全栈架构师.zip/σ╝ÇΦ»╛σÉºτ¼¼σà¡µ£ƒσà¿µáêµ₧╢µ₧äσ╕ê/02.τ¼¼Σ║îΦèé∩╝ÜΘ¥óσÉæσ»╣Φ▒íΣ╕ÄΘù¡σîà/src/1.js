let a=12;
let b=5;

let show=(a,b)=>a+b;

alert(show(a, b));
