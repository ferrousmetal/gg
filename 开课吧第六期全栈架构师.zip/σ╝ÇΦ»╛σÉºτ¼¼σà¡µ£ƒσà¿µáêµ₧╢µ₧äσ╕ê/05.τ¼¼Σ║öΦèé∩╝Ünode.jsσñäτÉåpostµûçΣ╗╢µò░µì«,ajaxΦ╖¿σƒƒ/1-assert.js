const assert=require('assert');

//assert(5<3, 'aaa');

//assert.deepEqual(变量, 预期值, msg);
//assert.deepStrictEqual(变量, 预期值, msg);
